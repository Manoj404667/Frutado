
var XJV=91;
var XRq=92;
var XKT=93;
var XKW=94;
var XLa=95;
var XLz=96;
var XNc=97;
var XM9=98;
function Xa8(){
this.type=XJV;}
function XM7(){
this.type=XM9;}
function XRa(Xh8){
this.type=XRq;
this.language=Xh8;}
function Xaw(){
this.type=XKT;}
function XGa(XfX){
this.type=XKW;
this.XfW=XfX;}
function XIN(xbw){
this.type=XLz;
this.xBH=xbw;}
function XGi(XiS,XiO){
this.type=XLa;
this.XiP=XiS;
this.XiN=XiO;}
function XIQ(XHY){
this.type=XNc;
this.x1N=XHY;}
if(self.XI7){XI7.XJB(new XIX('../gui_events.js'));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
