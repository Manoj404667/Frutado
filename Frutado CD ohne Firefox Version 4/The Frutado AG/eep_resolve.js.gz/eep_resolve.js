
////
var Eep_resolve;
var eep_resolveOptions={
eep_firstTextRe:null
,eep_useText:true
,eep_version:'6.1.1'};
Eep_resolve=function(xVh,xVG,XKF){
var XHZ=new Eep(xVh,eep_resolveOptions);
return XHZ.eep_resolve(xVG,XKF);}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
