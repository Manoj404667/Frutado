//
var XM4=[
{n:'version',js:0,xkI:2,xmE:'datango trainer 6.3.1.114'
+' [IE5.5ff,Moz1.7ff;AICC;SCORM]',x3G:true,x:"Xv"}
,{n:'browser',js:0,xkI:2,xmE:'unknown',x:"xOD"}
,{n:'browsertype',js:0,xkI:2,xmE:'?',x:"XIO"}
,{n:'browserversion',js:0,xkI:2,xmE:999,x:"xyQ"}
,{n:'guiheight',js:2,xkI:2,xmE:0,x:"guiheight"}
,{n:'guilanguages',js:0,xkI:2,xmE:
'bg,cs,da,de-DE,el,en-GB,en-US,es-ES,et,fi,fr-CA,fr-FR,hi,hr-HR,hu,id,it-IT,ja,ko,lt,lv,nb,nl-NL,pl,pt-BR,pt-PT,ro,ru,sk,sl,sv-SE,th,tr,uk,vi,zh-CN,zh-TW'
,x:"Xf2"}
,{n:'open',js:2,xkI:2,xmE:'',x:"open"}
,{n:'splithome',js:0,xkI:2,xmE:null,x:"xJK"}
,{n:'ok',js:2,xkI:0,xmE:false,x:"x6K"}
,{n:'aicc_sid',js:0,xkI:0,xmE:'',x:"aicc_sid",xwK:1},{n:'aicc_url',js:0,xkI:0,xmE:'',x:"aicc_url",xwK:1},{n:'anybrowser',js:2,xkI:0,xmE:false,x:"xkC"},{n:'appframename',js:0,xkI:0,xmE:'webride_frame',x:"Xan"},{n:'appname',js:0,xkI:0,xmE:'',x:"XG0"},{n:'apptimeout',js:0,xkI:0,xmE:0,x:"XG1"},{n:'appurl',js:0,xkI:0,xmE:'',x:"xAU"},{n:'autofocus',js:2,xkI:0,xmE:true,x:"Xct"},{n:'autoplace',js:2,xkI:0,xmE:true,x:"autoplace"},{n:'autoscroll',js:2,xkI:0,xmE:true,x:"XqP"},{n:'autostart',js:0,xkI:0,xmE:null,x:"x3C"},{n:'base',js:0,xkI:0,xmE:null,x:"x7C"},{n:'brand',js:2,xkI:0,xmE:true,x:"xND"},{n:'bubblefeedback',js:2,xkI:0,xmE:1,x:"Xvq"},{n:'bubbletransition',js:0,xkI:0,xmE:'',x:"xCz"},{n:'charset',js:0,xkI:0,xmE:'iso-8859-1',x:"charset"},{n:'clock',js:2,xkI:0,xmE:false,x:"clock"},{n:'config',js:0,xkI:0,xmE:null,x:"xNE"},{n:'contentlanguage',js:0,xkI:0,xmE:'',x:"XBe"},{n:'css',js:0,xkI:0,xmE:null,x:"XZL"},{n:'data',js:0,xkI:0,xmE:'resource/',x:"xGk"},{n:'defaultmediaquality',js:0,xkI:0,xmE:1,x:"XCv"},{n:'domain',js:0,xkI:0,xmE:null,x:"domain"},{n:'dynloadSecWindows',js:2,xkI:0,xmE:false,x:"XuW"},{n:'errorpage',js:0,xkI:0,xmE:'error',x:"xqF"},{n:'feedbackstyle',js:1,xkI:0,xmE:'',x:"Xah"},{n:'forward',js:0,xkI:0,xmE:null,x:"xOG"},{n:'guilanguage',js:0,xkI:0,xmE:'',x:"XLf"},{n:'gzip',js:2,xkI:0,xmE:true,x:"Xat"},{n:'hidden',js:2,xkI:0,xmE:false,x:"xfH"},{n:'highwater',js:0,xkI:0,xmE:'8.0',x:"xoh"},{n:'imagedir_bubbles',js:0,xkI:0,xmE:'bubbles',x:"X9p"},{n:'jsdebug',js:2,xkI:0,xmE:false,x:"xhg"},{n:'jscrash',js:2,xkI:0,xmE:false,x:"XTw"},{n:'jscrash2',js:2,xkI:0,xmE:false,x:"XnH"},{n:'keepbug',js:2,xkI:0,xmE:0,x:"Xbh"},{n:'keys',js:2,xkI:0,xmE:
'{f12:"_STOP",f8:"_PLAY",shift_f8:"_PREV",pause:"_PAUSE",alt_up:"_BACK",alt_down:"_NEXT"}',x:"X6C"},{n:'keys_invertedkeys_PLAY',js:0,xkI:0,xmE:'f8',x:"keys_invertedkeys_PLAY",m:true},{n:'keys_invertedkeys_STOP',js:0,xkI:0,xmE:'f12',x:"keys_invertedkeys_STOP",m:true},{n:'keys_invertedkeys_PAUSE',js:0,xkI:0,xmE:'pause',x:"keys_invertedkeys_PAUSE",m:true},{n:'keys_invertedkeys_PREV',js:0,xkI:0,xmE:'shift_f8',x:"keys_invertedkeys_PREV",m:true},{n:'keys_invertedkeys_BACK',js:0,xkI:0,xmE:'alt_up',x:"keys_invertedkeys_BACK",m:true},{n:'keys_invertedkeys_NEXT',js:0,xkI:0,xmE:'alt_down',x:"keys_invertedkeys_NEXT",m:true},{n:'library',js:0,xkI:0,xmE:null,x:"xAJ"},{n:'librarydefaults',js:1,xkI:0,xmE:'',x:"XNl"},{n:'librarydefaults_INP_Search',js:0,xkI:0,xmE:'',x:"librarydefaults_INP_Search",m:true},{n:'librarydefaults_INP_Filter',js:0,xkI:0,xmE:'',x:"librarydefaults_INP_Filter",m:true},{n:'librarydefaults_INP_FlagInDescription',js:2,xkI:0,xmE:true,x:"librarydefaults_INP_FlagInDescription",m:true},{n:'librarydefaults_INP_FlagInTitle',js:2,xkI:0,xmE:true,x:"librarydefaults_INP_FlagInTitle",m:true},{n:'librarydefaults_INP_FlagKeepCourse',js:2,xkI:0,xmE:false,x:"librarydefaults_INP_FlagKeepCourse",m:true},{n:'librarydefaults_INP_FlagNewWindow',js:2,xkI:0,xmE:false,x:"librarydefaults_INP_FlagNewWindow",m:true},{n:'librarydetails',js:0,xkI:0,xmE:'library_details.html',x:"Xlz"},{n:'libraryshow',js:2,xkI:0,xmE:true,x:"xDJ"},{n:'librarysize',js:0,xkI:0,xmE:'350',x:"XUy"},{n:'libraryskin',js:0,xkI:0,xmE:'',x:"xTJ"},{n:'libraryfilter',js:0,xkI:0,xmE:'',x:"libraryfilter"},{n:'libraryUseXMLHttpRequest',js:0,xkI:0,xmE:'',x:"Xv7"},{n:'libraryNewStyle',js:0,xkI:0,xmE:false,x:"Xv6"},{n:'live',js:1,xkI:0,xmE:'',x:"XoM"},{n:'lms',js:1,xkI:0,xmE:'',x:"X27"},{n:'lms_cfg_use_original_max',js:0,xkI:0,xmE:true,x:"lms_cfg_use_original_max",m:true},{n:'lms_cfg_score_percentage_100',js:0,xkI:0,xmE:false,x:"lms_cfg_score_percentage_100",m:true},{n:'lms_cfg_score_precision',js:0,xkI:0,xmE:3,x:"lms_cfg_score_precision",m:true},{n:'lms_cfg_only_one_commit',js:0,xkI:0,xmE:false,x:"lms_cfg_only_one_commit",m:true},{n:'lms_cfg_score_precedence_lms',js:0,xkI:0,xmE:false,x:"lms_cfg_score_precedence_lms",m:true},{n:'lms_cfg_decide_completeness',js:2,xkI:0,xmE:0,x:"lms_cfg_decide_completeness",m:true},{n:'lms_cfg_ignore_errors',js:2,xkI:0,xmE:false,x:"lms_cfg_ignore_errors",m:true},{n:'lms_cfg_deactivate_lms',js:2,xkI:0,xmE:false,x:"lms_cfg_deactivate_lms",m:true},{n:'log',js:0,xkI:0,xmE:'log.php',x:"Xl"},{n:'logurl',js:0,xkI:0,xmE:'',x:"XzA"},{n:'loguser',js:0,xkI:0,xmE:'',x:"Xyz"},{n:'logpwd',js:0,xkI:0,xmE:'',x:"XjP"},{n:'logsid',js:0,xkI:0,xmE:'',x:"Xvr"},{n:'lowwater',js:0,xkI:0,xmE:'2.0',x:"Xal"},{n:'macroset',js:0,xkI:0,xmE:'',x:"xAA"},{n:'macroset_files',js:0,xkI:0,xmE:null,x:"XrC"},{n:'macroset_name',js:0,xkI:0,xmE:null,x:"XrD"},{n:'maxbandwidth',js:0,xkI:0,xmE:'2400',x:"XbH"},{n:'mediaqualities',js:0,xkI:0,xmE:'.gsm.wav;.mp3',x:"XG3"},{n:'mediaselector',js:0,xkI:0,xmE:'DATANGO_MEDIASELECTOR',x:"XG4"},{n:'mode',js:0,xkI:0,xmE:'',x:"xKK"},{n:'mousespeed',js:2,xkI:0,xmE:1.5,x:"Xoc"},{n:'mousetick',js:2,xkI:0,xmE:200,x:"Xod"},{n:'mute',js:2,xkI:0,xmE:false,x:"xcK"},{n:'passive',js:2,xkI:0,xmE:true,x:"xkg"},{n:'playsounds',js:2,xkI:0,xmE:false,x:"XyV"},{n:'project',js:0,xkI:0,xmE:'trainer:',x:"XMG"},{n:'program',js:0,xkI:0,xmE:null,x:"xBH"},{n:'proxypath',js:0,xkI:0,xmE:'',x:"x5L"},{n:'recording_mode',js:0,xkI:0,xmE:false,x:"Xf7"},{n:'referrer',js:2,xkI:0,xmE:false,x:"referrer"},{n:'ride',js:0,xkI:0,xmE:null,x:"xoM"},{n:'resourcebase',js:0,xkI:0,xmE:'trainer:',x:"XMP"},{n:'scroll_x',js:0,xkI:0,xmE:0.4,x:"XMQ"},{n:'scroll_y',js:0,xkI:0,xmE:0.4,x:"XMR"},{n:'showSecondaryGuis',js:2,xkI:0,xmE:false,x:"showSecondaryGuis"},{n:'skin',js:0,xkI:0,xmE:'',x:"xnN"},{n:'skip',js:2,xkI:0,xmE:true,x:"xoN"},{n:'startpage',js:0,xkI:0,xmE:'start',x:"x0N"},{n:'stoppage',js:0,xkI:0,xmE:'stop',x:"Xau"},{n:'synopsis',js:2,xkI:0,xmE:true,x:"xPO"},{n:'textfileUseXMLHttpRequest',js:2,xkI:0,xmE:false,x:"xBb"},{n:'ticktime',js:2,xkI:0,xmE:50,x:"xWP"},{n:'timeout',js:2,xkI:0,xmE:-1,x:"timeout"},{n:'title',js:0,xkI:0,xmE:'',x:"title"},{n:'topmost',js:2,xkI:0,xmE:-1,x:"Xf5"},{n:'topmost_style',js:1,xkI:0,xmE:'',x:"Xok"},{n:'topmost_style_cfg_base',js:0,xkI:0,xmE:'',x:"topmost_style_cfg_base",m:true},{n:'topmost_style_cfg_minigui',js:2,xkI:0,xmE:false,x:"topmost_style_cfg_minigui",m:true},{n:'topmost_style_cfg_closeOnIdle',js:2,xkI:0,xmE:0,x:"topmost_style_cfg_closeOnIdle",m:true},{n:'topmost_style_cfg_scrollable',js:2,xkI:0,xmE:false,x:"topmost_style_cfg_scrollable",m:true},{n:'topmost_style_cfg_skin',js:0,xkI:0,xmE:'',x:"topmost_style_cfg_skin",m:true},{n:'topmost_style_cfg_show_startpage',js:2,xkI:0,xmE:false,x:"topmost_style_cfg_show_startpage",m:true},{n:'topmostMinPosition',js:2,xkI:0,xmE:3,x:"XyX"},{n:'topmostMinAnimate',js:2,xkI:0,xmE:false,x:"XyW"},{n:'tour',js:0,xkI:0,xmE:null,x:"Xav"},{n:'tourframe',js:0,xkI:0,xmE:null,x:"xqP"},{n:'tr',js:1,xkI:0,xmE:'',x:"xyP"},{n:'transition',js:0,xkI:0,xmE:'',x:"X6s"},{n:'ui',js:2,xkI:0,xmE:false,x:"XkC"},{n:'urlparam',js:2,xkI:0,xmE:false,x:"xkQ"},{n:'verbose',js:0,xkI:0,xmE:null,x:"xuQ"},{n:'window',js:1,xkI:0,xmE:'',x:"window"},{n:'window_cfg_top',js:0,xkI:0,xmE:'',x:"window_cfg_top",m:true},{n:'window_cfg_left',js:0,xkI:0,xmE:'',x:"window_cfg_left",m:true},{n:'window_cfg_width',js:0,xkI:0,xmE:'',x:"window_cfg_width",m:true},{n:'window_cfg_height',js:0,xkI:0,xmE:'',x:"window_cfg_height",m:true},{n:'window_cfg_orientation',js:0,xkI:0,xmE:'',x:"window_cfg_orientation",m:true},{n:'window_cfg_name',js:0,xkI:0,xmE:'',x:"window_cfg_name",m:true},{n:'window_cfg_features_fullscreen',js:0,xkI:0,xmE:false,x:"window_cfg_features_fullscreen",m:true},{n:'window_cfg_features_menubar',js:0,xkI:0,xmE:true,x:"window_cfg_features_menubar",m:true},{n:'window_cfg_features_toolbar',js:0,xkI:0,xmE:true,x:"window_cfg_features_toolbar",m:true},{n:'window_cfg_features_location',js:0,xkI:0,xmE:true,x:"window_cfg_top",m:true},{n:'window_cfg_features_resizable',js:0,xkI:0,xmE:true,x:"window_cfg_features_resizable",m:true},{n:'window_cfg_features_scrollbars',js:0,xkI:0,xmE:true,x:"window_cfg_features_scrollbars",m:true},{n:'window_cfg_features_status',js:0,xkI:0,xmE:true,x:"window_cfg_features_status",m:true},{n:'workaroundIEDocTypeBug',js:0,xkI:0,xmE:false,x:"Xzh"},{n:'xbubble_autohide',js:2,xkI:0,xmE:false,x:"xbubble_autohide"},{n:'xbubble_scroll',js:0,xkI:0,xmE:0.2,x:"XYm"}];
var XWC=/^[ \r\n\t\xA0]*(.*$)/m;
var XWw=/[ \r\n\t\xA0]*$/m;
String.prototype.XZB=function(){
return XWC.exec(this)[1];}
String.prototype.XZD=function(){
var match=XWw.exec(this);
return this.substr(0,this.length-match[0].length);}
String.prototype.XZA=function(){
var xd2=this.XZB();
return xd2.XZD();}
String.prototype.XPC=function(){
xd2=new String(this);
xd2=xd2.replace(/[\\]/g,"\\\\");
xd2=xd2.replace(/[""]/g,'\\"');
xd2=xd2.replace(/[\n]/g,'\\n');
xd2=xd2.replace(/[\r]/g,'\\r');
xd2=xd2.replace(/[\t]/g,'\\t');
return '"'+xd2+'"';}
var X3G=(new String('1')).charCodeAt(0);
var X3H=(new String('9')).charCodeAt(0);
var X3I=(new String('@')).charCodeAt(0);
var X3J=/^[1-9]_[^_]+_/;
String.prototype.X61=function(X7L){
var X7K=
(typeof(X7L)=='object'&&
typeof(X7L.length)=='number'?X7L:arguments);
var xd2='';
var X68=this;
var xoL=X68.indexOf('@');
var c;
while(xoL>=0){
xd2+=X68.substr(0,xoL);
X68=X68.substr(xoL+1);
c=X68.substr(0,1).charCodeAt(0);
if(c>=X3G&&c<=X3H){
c-=X3G;
if(c<X7K.length){
xd2+=(''+X7K[c]);}
xoL=X68.search(X3J);
if(xoL==0){
xoL=X68.indexOf('_',2);
X68=X68.substr(xoL+1);}
else{
X68=X68.substr(1);}}
else if(c==X3I){
xd2+='@';
X68=X68.substr(1);}
xoL=X68.indexOf('@');}
return xd2+X68;}
var X3F=/[^a-zA-Z0-9_]/g;
String.prototype.X3m=function(){
return this.replace(X3F,'_');}
function XAZ(XCZ,XCY,XHh,xaq){
this.XCZ=XCZ;
this.XCY=XCY;
this.XHh=XHh||XJO;
this.xaq=xaq;}
XAZ.prototype={
XCZ:null
,XCY:null
,XfF:null
,xaq:null
,XKe:function(){
return this.XCZ;}
,XKd:function(){
return this.XCY;}
,exec:function(XHg_,xaq){
var xbK=XHg_||'';
if(!this.XCY){
this.XHh('CB exec('+xbK+'):no func');
return true;}
if(this.XCZ){
this.XHh('CB exec('+xbK+'):obj.func');
return this.XCY.call(this.XCZ,xaq,this.xaq);}
this.XHh('CB exec('+xbK+'):no obj');
return this.XCY(xaq,this.xaq);}}
function XJO(){
return true;}
//
function Url(xMj){
this.x6K=(xMj?this.xax(xMj):false);
if(this.x6K){
this.XMO();}}
Url.prototype.XCf=function(){
var url=new Url;
if(this.Xxl){
url.Xxe=this.Xxe;
url.Xxl=this.Xxl.XCf();}
url.xzk=this.xzk;
url.XIG=this.XIG;
url.xay=this.xay;
url.XHF=this.XHF;
url.xbo=this.xbo;
url.xaz=this.xaz;
url.XHA=this.XHA;
url.XFf=this.XFf;
url.x6K=true;
return url;}
xLJ=function(xfK,xMj){
if(Url.prototype.XMU[xfK]===false){
return false;}
switch(typeof(xMj)){
case 'string':
Url.prototype.XMU[xfK]=new Url(xMj);
break;
case 'object':
Url.prototype.XMU[xfK]=
(xMj?xMj.XCf():null);
break;
default:
return false;}
return true;}
XWf=function(xFR){
var XWi=false;
var code;
if(!XRl){
try{
var xMj=decodeURI(xFR);
xtg=false;}
catch(xa8){
xtg=false;
for(var i=0;i<xFR.length;++i){
code=xFR.charCodeAt(i);
if(code<=32||code>=127){
XWi=true;}}}}
else{
for(var i=0;i<xFR.length;++i){
code=xFR.charCodeAt(i);
if(code<=32||code>=127){
XWi=true;}}}
return(XWi?escape(xFR):xFR);}
Url.prototype.x6K=false;
Url.prototype.X9v=function(){
var xbK=(this.xzk==''?
(this.XHF!=''?'http:':''):
this.xzk+':');
if(this.XHF!=''||this.xzk=='file'){
(this.xzk=='mk')||
(xbK+=('/'+'/'));
if(this.XIG!=''){
xbK+=this.XIG;
if(this.xay!=''){
xbK+=(':'+this.xay);}
xbK+='@';}
if(this.XHF.match(xKJ)){
xbK+='/'+this.XHF;}
else{
xbK+=this.XHF;}
if(this.xbo!=''){
xbK+=':'+this.xbo;}}
if(this.xaz!=''){
xbK+=escape(this.xaz);}
if(this.XHA!=''){
xbK+=('?'+escape(this.XHA));}
if(this.XFf!=''){
xbK+=('#'+escape(this.XFf));}
return xbK;}
Url.prototype.XEZ=function(){
return this.XFf;}
Url.prototype.XFG=function(){
return this.xaz;}
Url.prototype.XFF=function(){
return this.xay;}
Url.prototype.XFH=function(){
return this.xbo;}
Url.prototype.XFJ_=function(){
return this.xzk;}
Url.prototype.XFP=function(){
return this.XHA;}
Url.prototype.XFQ=function(){
if(this.xd6==null){
this.xav();}
return this.xd6;}
Url.prototype.XFR=function(){
if(this.xd9==null){
this.xav();}
return this.xd9;}
Url.prototype.Xke=function(){
return this.XIG;}
Url.prototype.XFT=function(){
return this.XHF;}
Url.prototype.valueOf=function(){
return this.toString();}
Url.prototype.toString=function(){
var xbK=(this.xzk==''?
(this.XHF!=''?'http:':''):
this.xzk+':');
if(this.XHF!=''||this.xzk=='file'){
(this.xzk=='mk')||
(xbK+=('/'+'/'));
if(this.XIG!=''){
xbK+=this.XIG;
if(this.xay!=''){
xbK+=(':'+this.xay);}
xbK+='@';}
if(this.XHF.match(xKJ)){
xbK+='/'+this.XHF;}
else{
xbK+=this.XHF;}
if(this.xbo!=''){
xbK+=':'+this.xbo;}}
if(this.xaz!=''){
xbK+=this.xaz;}
if(this.XHA!=''){
xbK+=('?'+this.XHA);}
if(this.XFf!=''){
xbK+=('#'+this.XFf);}
if(this.Xxe!=''){
xbK=this.Xxe+xbK;
if(this.Xxl){
xbK=xbK+'!'+this.Xxl.toString();}
if(this.xzk=='file'){
xoL=xbK.indexOf('!');
var XYA=xbK.substr(0,xoL);
var XYB=xbK.substr(xoL);
xbK=XYA.replace('mhtml:file:///','mhtml:').replace(/\//g,'\\')+XYB;}}
return xbK;}
Url.prototype.XDf=function(){
var xbK=
'|'+this.xzk+
'|'+this.XIG+
'|'+this.xay+
'|'+this.XHF+
'|'+this.xbo+
'|'+this.xaz+
'|'+this.XHA+
'|'+this.XFf+
'|';
return xbK;}
Url.prototype.XQl=function(){
var xbK='';
for(var name in Url.prototype.XMU){
xbK+=','+name+':'+Url.prototype.XMU[name];}
return 'Url.specialProtocolContainer_={'+xbK.substr(1)+'}';}
Url.prototype.xc3=function(XCR){
var xAD=(typeof(XCR)=='string'?new Url(XCR):XCR);
var x7N=false;
if(this.xzk==''){
this.xzk=xAD.xzk;}else{
if(xAD.xzk!=''&&
xAD.xzk!=this.xzk)
{
x7N=true;}}
if(!x7N&&this.XHF==''){
this.XHF=xAD.XHF;
this.XIG=xAD.XIG;
this.xay=xAD.xay;
this.xbo=xAD.xbo;}
else{
if(xAD.XHF!=''&&
xAD.XHF!=this.XHF)
{
x7N=true;}}
if(!x7N){
if(this.xaz==''){
this.xaz=xAD.xaz;}
else{
if(this.xaz.substr(0,1)=='/'){if(xAD.xaz!=this.xaz){
x7N=true;}}
else{
if(xAD.Xxe=='mhtml:'){
var path=this.xaz;
this.Xxj('http://dgo_mht_proxy/'+this.xaz);
this.xaz=xAD.xaz;}
else{
x7N=true;
if(xAD.xaz.indexOf('/')>=0){
var path=this.xaz;
this.XC4(xAD.xaz,true);
this.XC5();
this.XCJ(path,true);}}}}}
if(!x7N&&this.XHA==''){
this.XHA=xAD.XHA;}
else{
if(xAD.XHA!=''&&
xAD.XHA!=this.XHA)
{
x7N=true;}}
if(!x7N&&this.XFf==''){
this.XFf=xAD.XFf;}
return true;}
Url.prototype.xc4=function(xa6){
var url=new Url(xa6);
url.x6K=url.xc3(this);
return url;}
Url.prototype.XC7=function(xFR){
this.xzk=xFR;
return true;}
Url.prototype.XCa=function(xFR,XWj){
this.XIG=(XWj?xFR:escape(xFR));
return true;}
Url.prototype.XC3=function(xFR,XWj){
this.xay=(XWj?xFR:escape(xFR));
return true;}
Url.prototype.XC9=function(xFR,XWj){
this.XHF=(XWj?xFR:escape(xFR));
return true;}
Url.prototype.XC6=function(xFR){
this.xbo=xFR;
return true;}
Url.prototype.XC4=function(xFR,XWj){
var x=xFR.replace(XEk,'/');
this.xaz=(XWj?x:escape(x));
this.XK6();
return true;}
Url.prototype.XC5=function(){
var i=this.xaz.lastIndexOf('/');
if(i<0){
this.xaz='';}
else if(i+1<this.xaz.length){
this.xaz=this.xaz.substr(0,i);}
return this.xaz;}
Url.prototype.XC8=function(xFR){
this.xd6=null;
this.xd9=null;
this.XHA=xFR;
return true;}
Url.prototype.XC2=function(xFR,XWj){
this.XFf=(XWj?xFR:escape(xFR));
return true;}
Url.prototype.XCJ=function(XCA,XWj){
var add=XCA.replace(XEk,'/');
if(!XWj){
add=escape(add);}
var xkI=this.xaz.length;
var path=(this.xaz.substr(xkI-1)=='/'?
this.xaz.substr(0,xkI-1):this.xaz);
this.xaz=path+'/'+
(add.substr(0,1)=='/'?add.substr(1):add);
this.XK6();
return this.xaz;}
Url.prototype.Xxj=function(XCA){
this.Xxl=new Url(XCA);
if(this.Xxl.x6K||XCA==''){
this.Xxe='mhtml:';}
else{
this.Xxe='';}
return this.Xxl.xaz;}
Url.prototype.Xxc=function(){
return this.Xxl;}
Url.prototype.XCK=function(xFR,XWj){
if(!xFR){
return;}
this.xd6=null;
this.xd9=null;
this.XHA+=(this.XHA?'&':'')+
(XWj?xFR:escape(xFR));
return this.XHA;}
Url.prototype.XWg=function(xfK,XIH,XWj){
if(!xfK&&!XIH){
return;}
this.xd6=null;
this.xd9=null;
this.XHA+=(this.XHA?'&':'')+xfK+'='+
(XWj?XIH:escape(XIH));
return this.XHA;}
Url.prototype.Xxe='';
Url.prototype.Xxl=null;
Url.prototype.xzk='';
Url.prototype.XIG='';
Url.prototype.xay='';
Url.prototype.XHF='';
Url.prototype.xbo='';
Url.prototype.xaz='';
Url.prototype.XHA='';
Url.prototype.xd6=null;
Url.prototype.xd9=null;
Url.prototype.XFf='';
Url.prototype.XMU={
https:false,
http:false,
ftp:false,
file:false,
archie:false,
gopher:false};
var XEk=/\\/g;
var XkD=/^[a-zA-Z]$/;
var xKJ=/^[a-zA-Z][:]$/;
var xDO=/^(([^:\/?#]+):)?(\/\/(([^:@\/?#]*)?(:([^@\/?#]*))?@)?([^:\/?#]*)(:([^\/?#]+))?)?((\/)?[^?#]*)?(\?([^#]*))?(#(.*))?$/;
Url.prototype.xax=function(XkX){
if(XkX.substr(0,11)=='javascript:'){
this.xzk='javascript';
this.XIG='';
this.xay='';
this.XHF='';
this.xbo='';
this.xaz=XkX.substr(11);
this.XHA='';
this.XFf='';
return true;}
if(XkX.substr(0,6)=='mhtml:'){
this.Xxe='mhtml:';
XkX=XkX.substr(6);
var xoL=XkX.indexOf('!');
this.Xxj(XkX.substr(xoL+1));
XkX=XkX.substr(0,xoL);}
var xHQ=XkX.replace(XEk,'/');
var xDk=xDO.exec(xHQ)||[];
this.xzk=xDk[2]||'';
this.XIG=xDk[5]||'';
this.xay=xDk[7]||'';
this.XHF=xDk[8]||'';
this.xbo=xDk[10]||'';
this.xaz=xDk[11]||'';
this.XHA=xDk[14]||'';
this.XFf=xDk[16]||'';
if(this.xzk=='mk'&&this.XHF==''){
var xoL=this.xaz.indexOf('::');
if(xoL>=0){
this.XHF=this.xaz.substr(0,xoL+2);
this.xaz=this.xaz.substr(xoL+2);}}
if(!this.XIG&&!this.xay&&!this.xbo){
if(!this.XHF&&this.xzk.match(XkD)){
this.XHF=this.xzk+':';
this.xzk='file';}
else if(this.xzk=='file'&&
this.xaz.substr(0,1)==':'&&
this.XHF.match(XkD))
{
this.XHF+=':';
this.xaz=this.xaz.substr(1);}
else if(this.xzk=='file'&&
!this.XHF&&
this.xaz.substr(2,1)==':'&&
this.xaz.substr(1,1).match(XkD))
{
this.xzk='file';
this.XHF=this.xaz.substr(1,2);
this.xaz=this.xaz.substr(3);}
else if(this.xzk==''&&
XkX.substr(0,2)=='\\\\'&&
this.XHF.indexOf('.')<0)
{
this.xzk='file';}}
this.XHF=XWf(this.XHF);
this.xaz=XWf(this.xaz);
this.XK6();
this.xd6=null;
this.xd9=null;
return(XkX&&(this.Xxe==''||this.Xxl.x6K)?
xDk.length>0:false);}
Url.prototype.XK6=function(){
if(!this.xaz){
return true;}
this.xaz=this.xaz.replace(/\\/g,'/');
if(XRl){
var xBr=new RegExp('/'+'/','g');
do{
var xBq=this.xaz;
this.xaz=this.xaz.replace(xBr,'/');}
while(xBq!=this.xaz);}
var XK8=this.xaz.split('/');
var xkI=XK8.length;
var i=0;
var XK7;
while(i<xkI){
XK7=XK8[i];
if(XK7=='.'){
if(i+1==xkI){
XK8[i]='';}else{
if(i>0||xkI!=2||(XK8[1]!=''&&XK8[1]!='.')){
var XL8=[];
if(i>0){
XL8=XL8.concat(XK8.slice(0,i));}
if(i<xkI){
XL8=XL8.concat(XK8.slice(i+1));}
XK8=XL8;
--i;
--xkI;}}}
else if(XK7=='..'){
if(i>0&&XK8[i-1]&&XK8[i-1]!='..'){
var XL8=[];
if(i-1>0){
XL8=XL8.concat(XK8.slice(0,i-1));}
if(i<xkI){
XL8=XL8.concat(XK8.slice(i+1));}
XK8=XL8;
xkI-=2;
i-=2;}}
++i;}
this.xaz='';
for(i=0;i<XK8.length;++i){
this.xaz+=(i>0?'/':'')+XK8[i];}
return true;}
Url.prototype.XMO=function(){
var x7C;
while(typeof(
x7C=this.XMU[this.xzk])=='object'&&
x7C)
{
if(this.xzk=='mht'){
this.x6K=this.xax(x7C.toString()+this.xaz);}
else{
this.XC7(x7C.XFJ_());
this.xc3(x7C);}}
return false;}
Url.prototype.xav=function(){
this.xd6=[];
this.xd9=[];
if(!this.XHA){
return true;}
var xar=this.XHA.split('&');
for(var i=0;i<xar.length;++i){
var xPL=xar[i];
var xLI=xPL.search('=');
if(xLI>=0){
this.xd6[i]=xPL.substr(0,xLI);
this.xd9[i]=xPL.substr(xLI+1);}
else{
this.xd6[i]=xPL;
this.xd9[i]='';}}
return true;}
function XX4(X6H,XIH){
var xYE;
if(typeof(X6H)=='string'){
XYE[X6H]=XIH+'';
xYE=1;}
else if(typeof(X6H)=='object'){
xYE=0;
for(var name in X6H){
XYE[name]=X6H[name]+'';
++xYE;}}
else{
return false;}
return xYE;}
function XXt(X8G,X8B,XPz,xVG,XCZ,XCY,xBJ){
var xyP=X8G||{};
var lang=X8B.toLowerCase();
for(var xC3 in xyP){
if(xC3.indexOf('_')>-1){
var xC4=xC3.replace(/_/,'-').toLowerCase();
xyP[xC4]=xyP[xC3];
xyP[xC3]=null;}}
if(typeof(xyP[lang])=='object'){
var xa7=XX4(xyP[lang]);
return xa7===false?-1:0;}
else if(typeof(xyP[lang])=='string'){
var url=new Url(xyP[lang]);
url.xc3(XPz);
return XP0(url.toString(),xVG,XCZ,XCY,xBJ);}
return-2;}
var X92=null;
var X99=null;
function XP0(xMj,xVG,XCZ,XCY,xBJ){
X99=xMj;
X92=new XAZ(XCZ,XCY);
return X9w(xMj,xVG,null,X51,null,xBJ);}
function xAx(xBC){var xAz="";
var i=0;
var c=X0M=xAv=0;
while(i<xBC.length){
c=xBC.charCodeAt(i);
if(c<128){
xAz+=String.fromCharCode(c);
i++;}
else if((c>191)&&(c<224)){
xAv=xBC.charCodeAt(i+1);
xAz+=String.fromCharCode(((c&31)<<6)|(xAv&63));
i+=2;}
else{
xAv=xBC.charCodeAt(i+1);xAw=xBC.charCodeAt(i+2);
xAz+=String.fromCharCode(((c&15)<<12)|((xAv&63)<<6)|(xAw&63));
i+=3;}}
return xAz;}
var XRU=/[\r\n]/m;
var XRV=/[;\t]./;
var XnW=/[^;\t ]./;
function X51(xyO){
var src=X99;
var xAX=X92;
X99=null;
X92=null;
if(typeof(xyO)!='string'){
xAX&&xAX.exec('Dict load error','Textfile "'+src+'" not loaded');
return false;}
var Xhu=xyO.split(XRU);
var xYE=0;
var i,xkI,xFJ,xoL,XK8,xkP,value,xbK;
var xBA=false;
if(Xhu.length>0&&
Xhu[0].charCodeAt(0)==239&&
Xhu[0].charCodeAt(1)==187){
xBA=true;}
for(i=0,xkI=Xhu.length;i<xkI;++i){
xFJ=Xhu[i];
xoL=xFJ.search(XRV);
if(xoL>=0&&(xkP=(xFJ.substr(0,xoL)||'').XZA())&&
xkP.substr(0,1)!='#')
{
value=xFJ.substr(xoL+1);
xoL=value.search(XnW);
value=xoL<0?'':value.substr(xoL);
value=value.XZD();
if(value.substr(0,1)=='"'){
value=value.substr(1,value.length-2);}
xoL=value.indexOf('""');
while(xoL>=0){
value=value.substr(0,xoL)+value.substr(xoL+1);
xoL=value.indexOf('""',xoL+1);}
value=value.replace(/\\t/g,'\t');
value=value.replace(/\\r/g,'\r');
XYE[xkP]=xBA?xAx(value.replace(/\\n/g,'\n')):value.replace(/\\n/g,'\n');
++xYE;}}
xAX.exec('Dict loaded',xYE);
return true;}
var XbE=/@\{([A-Za-z_][A-Za-z0-9_]+)\}/;
function XQK(xfK,X7L){
var name=xfK;
var X7K=[];
for(var i=1;
i<arguments.length&&typeof(arguments[i])!='undefined';
++i)
{
X7K[X7K.length]=arguments[i];}
if(typeof(XYE[name])!='string'){
return '['+name+':'+X7K+']';}
var value=XYE[name];
var xa7=value.match(XbE);
while(xa7){
value=value.replace(XbE,XQK(xa7[1]));
xa7=value.match(XbE);}
if(X7K.length<1){
return value;}
return value.X61(X7K);}
var XYE={};
var XRl=(navigator.appName=='Microsoft Internet Explorer');
var Xcf;
function Xcg(){
var XIy=self.document.getElementById('dgo_dhtml.js');
var url;
if(XIy&&XIy.tagName=='SCRIPT'){
url=new Url(XIy.src);
url.xc3(self.location.href);
url.XC5();}
else{
url=new Url(this.XHS);
url.XC8('');
url.XC2('');
url.XC5();}
Xcf=url.toString();
XlO=Xcf+'/icons/';}
function Xbp(x9Q,Xr0){
if(XRl){
var xbK='';
var xYE=0;
if(typeof(x9Q.location)=='unknown'){
xbK+=';win.loc unknown';
++xYE;}
else if(x9Q.location&&typeof(x9Q.location.protocol)=='unknown'){
xbK+='win.loc.protocol unknown';
++xYE;}
if(typeof(x9Q.document)=='unknown'){
xbK+=';win.doc unknown';
++xYE;}
else if(x9Q.document&&typeof(x9Q.document.readyState)=='unknown'){
xbK+=';win.doc.rs unknown';
++xYE;}
if(typeof(x9Q.name)=='unknown'){
xbK+='win.name unknown';
++xYE;}
if(xYE>1){
return xbK;}
if(Xr0){
return '';}
var XWi=false;
try{
XWi=
typeof(x9Q.document)=='object'&&x9Q.document&&
typeof(x9Q.document.body)!='unknown'&&!x9Q.document.body&&
x9Q.document.readyState=='complete';}
catch(xa8){
return 'win.doc.body exc';}
if(XWi){
var xkI;
if(0<(xkI=x9Q.document.getElementsByTagName('HTML').length)){
return 'complete,but no body;'+xkI+' HTML tag';}}}
else{
try{
var x=x9Q.location.protocol;
x=x9Q.name;}catch(e){
return 'window access exception';}}
return '';}
function XSS(x9Q){
if(XRl){
var xa7=Xbp(x9Q);
if(xa7){
return xa7;}
if(typeof(x9Q.closed)!='boolean'){
return 't(win.closed)'+typeof(x9Q.closed);}
if(typeof(x9Q.document)!='object'){
return 't(win.doc)'+typeof(x9Q.document);}
if(!x9Q.document){
return 'win.doc null';}
if(typeof(x9Q.document.body)!='object'){
return 't(win.doc.body)'+typeof(x9Q.document.body);}
if(!x9Q.document.body){
return 'win.doc.body null';}
if(typeof(x9Q.document.readyState)!='string'){
return 't(win.doc.rs)'+typeof(x9Q.document.readyState);}
if(typeof(x9Q.frames)!='object'){
return 't(win.frames)'+typeof(x9Q.frames);}
if(!x9Q.frames){
return 'win.frames null';}
if(typeof(x9Q.frames.length)!='number'){
return 't(win.frames.length)'+typeof(x9Q.frames.length);}}
else{
var xa7=Xbp(x9Q);
if(xa7){
return xa7;}
if(typeof(x9Q.closed)!='boolean'){
return 'typeof win.closed '+typeof(x9Q.closed);}
if(typeof(x9Q.document)!='object'){
return 'typeof win.doc '+typeof(x9Q.document);}
if(!x9Q.document){
return 'win.doc null';}
if(typeof(x9Q.document.body)!='object'){
return 'typeof win.doc.body '+typeof(x9Q.document.body);}
if(!x9Q.document.body){
return 'win.doc.body null';}
if(typeof(x9Q.frames)!='object'){
return 'typeof win.frames '+typeof(x9Q.frames);}
if(!x9Q.frames){
return 'win.frames null';}
if(typeof(x9Q.frames.length)!='number'){
return 'typeof win.frames.length '+typeof(x9Q.frames.length);}}
return '';}
function XOj(XGR,xfK){
var XNB=XGR.attributes;
var XCM;
if(typeof(XNB[xfK])!='unknown'&&XNB[xfK]){
XCM=XNB[xfK];if(XCM.nodeName==xfK){
return XCM.nodeValue;}}
for(var i=0;i<XNB.length;++i){
XCM=XGR.attributes[i];
if(XCM.nodeName==xfK){
return XCM.nodeValue;}}
return undefined;}
function Xw5(X8B){
switch(X8B.toLowerCase()){
case 'br':return 'pt-BR';
case 'de':return 'de-DE';
case 'es':return 'es-ES';
case 'en':return 'en-US';
case 'fr':return 'fr-FR';
case 'hr':return 'hr-HR';
case 'it':return 'it-IT';
case 'nl':return 'nl-NL';
case 'nn':return 'nb';
case 'no':return 'nb';
case 'pt':return 'pt-PT';
case 'sv':return 'sv-SE';
case 'tw':return 'zh-TW';
case 'zh':return 'zh-CN';}
if(X8B.indexOf('-')>0){
return X8B;}
else{
return X8B.toLowerCase();}}
function XOk(Xh7){
var Xh6=','+(Xh7||'en')+',';
var lang=Xw5((navigator.language||
navigator.browserLanguage||'').substr(0,2));
if(Xh6.indexOf(','+lang+',')>=0){
return lang;}
return Xh6.substr(1,Xh6.indexOf(',',1)-1);}
function XA4(XHS,XCz,Xzt){
if(typeof(Xzt)=='undefined'){
Xzt=false;}
var xAc=XCz||{};
var XCM,xoQ,xmE;
for(XCM in XHS){
xoQ=XHS[XCM];
switch(typeof(xoQ)){
case 'unknown':
case 'undefined':break;
case 'object':xAc[XCM]=Xzt?XA4(xoQ,xAc[XCM],Xzt):
XA4(xoQ);
break;
default:xAc[XCM]=xoQ;break;}}
return xAc;}
function XTd(XHS,XCz){
var xAc=XCz||{};
for(XCM in XHS){
xAc[XCM]=XHS[XCM];}
return xAc;}
function Xl(t,i,xkI){
if(typeof(dgoAgent)=='object'&&dgoAgent&&
(typeof(dgoAgent.Xpr)=='function'||
typeof(dgoAgent.Xpr)=='object')
)
{
dgoAgent.Xpr(t,i,xkI);}
else if(typeof(dgoN)=='object'&&dgoN&&
(typeof(dgoN.Xl)=='function'||
typeof(dgoN.Xl)=='object')
)
{
dgoN.Xl(t,i,xkI);}}
function XoT(t,i,xkI){typeof(self.dgoL)=='object'&&self.dgoL.Xl(t,i,xkI);};
Xcg();
var XP1=0;
function X9w(xMj,xVG,XCZ,XCY,XHh,xBJ){
var x4E=xVG.document;
var host=xVG.location.host;
var xoL=host.indexOf(':');
if(xoL>0){host=host.substr(0,xoL);}
if((xVG.location.protocol.substr(0,4)=='http'&&
host!=x4E.domain)||(xBJ===true))
{
if(XRl){
try{
var Xwg=new ActiveXObject("MSXML2.XMLHTTP.3.0");}
catch(xa8){
try{
Xwg=new ActiveXObject("Msxml2.XMLHTTP");}
catch(xa8){
try{
Xwg=new ActiveXObject("Microsoft.XMLHTTP");}
catch(xa8){
Xwg=null;
XHh&&
XHh('TF load error:Cannot create an XMLHTTP instance','exc');}}}
if(Xwg){
if(Xwg.overrideMimeType){
Xwg.overrideMimeType('text/plain');}
var Xbm=new XAZ(XCZ,XCY,XHh);
var NO=XP1;
var XwF=Xwg;
var X1K=function(xyO){
X9x(xyO,NO,false,
true,Xbm,
XwF);}
var url=new Url(xMj);
url.xc3(xVG.location.href);
var xbK='TF load "'+xMj+'" into XMLHTTP ';
XHh&&XHh(xbK);
Xwg.onreadystatechange=X1K;
try{
Xwg.open('GET',url.toString(),true);
Xwg.send(null);}
catch(xa8){
XHh&&
XHh('TF load error:Cannot send XMLHttp request','exc');
return false;}}
else{var x3E=x4E.createElement('DIV');
if(!x3E){
return-10;}
x3E.style.display='none';
x3E.id='dgoTextfile_'+(++XP1);
x3E.addBehavior("#default#download");
x3E.dgo52=new XAZ(XCZ,XCY,XHh);
if(!(x3E=x4E.body.appendChild(x3E))){
return-11;}
var NO=XP1;
var X1K=function(xyO){
X9x(xyO,NO,true);}
var url=new Url(xMj);
url.xc3(xVG.location.href);
x3E.dgoq=url.Xxc()&&
url.Xxc().toString().indexOf('http://dgo_mht_proxy/')<0?
url.Xxc().toString():url.toString();
var xbK='TF load "'+url.toString()+'" into DIV '+x3E.id;
x3E.startDownload(url.toString(),X1K);
XHh&&XHh(xbK+' using download behaviour. ');}}
else{var Xwg=new XMLHttpRequest();
if(!Xwg){
XHh&&
XHh('TF load error:Cannot create an XMLHTTP instance','exc');
return-12;}
if(Xwg.overrideMimeType){
Xwg.overrideMimeType('text/plain');}
var Xbm=new XAZ(XCZ,XCY,XHh);
var NO=XP1;
var XwF=Xwg;
var X1K=function(xyO){
X9x(xyO,NO,false,
true,Xbm,
XwF);}
var url=new Url(xMj);
url.xc3(xVG.location.href);
var xbK='TF load "'+xMj+'" into XMLHTTP ';
XHh&&XHh(xbK);
Xwg.onreadystatechange=X1K;
Xwg.open('GET',url.toString(),true);
try{
Xwg.send(null);}
catch(xa8){
XHh&&
XHh('TF load error:Cannot send XMLHttp request','exc');}}}
else{var XDm=x4E.createElement('IFRAME');
if(!XDm){
return-10;}
XDm.style.display='none';
XDm.id='dgoTextfile_'+(++XP1);
var x4E=xVG.document;
XDm.src=Xcf+'/about_blank.html';
XDm.dgo52=new XAZ(XCZ,XCY,XHh);
if(!(XDm=x4E.body.appendChild(XDm))){
return-11;}
if(typeof(XDm.readyState)=='string'){
XDm.onreadystatechange=X9x;}
else{
XDm.addEventListener('load',X9x,true);}
var url=new Url(xMj);
url.xc3(xVG.location.href);
XDm.dgoq=xVG.location.protocol.substr(0,4)=='file'&&
url.Xxc()&&
url.Xxc().toString().indexOf('http://dgo_mht_proxy/')<0?
url.Xxc().toString():
url.toString();
var xbK='TF load "'+url.toString()+'" into '+XDm.id;
try{
var x8Q=XDm.contentWindow;
if(typeof(x8Q)=='object'&&x8Q&&
typeof(x8Q.document)=='object'&&x8Q.document&&
typeof(x8Q.document.body)=='object'&&x8Q.document.body)
{
XHh&&XHh(xbK);
XDm.contentWindow.location.replace(url.toString());}
else{
XHh&&XHh(xbK+' using IFRAME.src');
XDm.src=url.toString();}}
catch(xa8){
XHh&&
XHh('TF load error:'+(new x6C(xa8)),'exc');
XDm.parentNode.removeChild(XDm);
return-12;}}
return 1;}
function Xrf(XI6){
var Xm6=XI6.getElementsByTagName('PRE')[0]||
XI6.getElementsByTagName('XMP')[0];
if(Xm6&&Xm6.childNodes&&Xm6.childNodes.length>0){
var text='';
for(var i=0;i<Xm6.childNodes.length;++i){
if(Xm6.childNodes[i].nodeType==3){
text+=Xm6.childNodes[i].nodeValue;}}
return text;}
return false;}
function X9x(xyO,XP1,XsE,Xwc,
Xwl,Xwh){
if(XsE){
var x3E=self.document.getElementById('dgoTextfile_'+XP1);
if(x3E){
var xAX=x3E.dgo52;
x3E.dgo52=null;
var xUB=x3E;
var XM6=function(){
try{xUB.parentNode.removeChild(xUB);}catch(xa8){}}
self.setTimeout(XM6,1000);}
else{
xAX.exec('Textfile '+XP1+' unaccessible',false);
return false;}}
else if(Xwc){
var xAX=Xwl;
if(Xwh.readyState==4){
if(Xwh.status==200){
xyO=Xwh.responseText;}
else{
if(window.location.protocol.substr(0,4)=='file'){
xyO=Xwh.responseText;}
else{
xAX.exec('Textfile '+XP1+' unaccessible',false);
return false;}}}
else{
return true;}}
else{
if(typeof(this.readyState)=='string'){
if(this.readyState!='complete'){
return true;}
if(!this.dgoq){
return true;}
this.onreadystatechange=null;}
else{
if(!this.dgoq){
return true;}
this.removeEventListener('load',X9x,true);}
var xAX=this.dgo52;
var src=this.dgoq;
var x8Q;
this.dgo52=null;
this.dgoq=null;
var Xjj=this;
var XM6=function(){
try{Xjj.parentNode.removeChild(Xjj);}catch(xa8){}}
try{
if(typeof(this.contentWindow)!='object'||
!(x8Q=this.contentWindow)||
typeof(x8Q.location)!='object'||
typeof(x8Q.location.href)!='string'||
typeof(x8Q.document)!='object'||
typeof(x8Q.document.body)!='object'){
x8Q.parent.setTimeout(XM6,1000);xAX.exec('Textfile '+this.id+'="'+src+
'" unaccessible',false);
return false;}}
catch(xa8){
x8Q.parent.setTimeout(XM6,1000);xAX.exec('Textfile '+this.id+'="'+src+
'" unaccessible',false);
return false;}
if(src!=x8Q.location.href&&
unescape(src)!=unescape(x8Q.location.href))
{x8Q.parent.setTimeout(XM6,1000);xAX.exec('Textfile '+this.id+'="'+x8Q.location+
'" wrong or missing;req "'+
src+'"',false);
return false;}
xyO=Xrf(x8Q.document);
x8Q.parent.setTimeout(XM6,1000);}
if(xyO===false){
xAX.exec('Textfile '+this.id+'="'+src+'" not loaded',false);
return false;}
xAX.exec('Textfile loaded',xyO);
return true;}
function xGB(xVG,XmO,XmJ,XHh){
this.XHh=XHh||XPR;
if(!xVG||!xVG.document||!xVG.document.body){
this.error='base frame unready(doc.body missing)';
var xbK='Config:'+this.error;
this.XHh('CFG '+xbK,'error');
return;}
if(xVG.document.body.tagName!='BODY'){
this.error='base frame must not be '+
xVG.document.body.tagName+'(need BODY)';
var xbK='Config:'+this.error;
this.XHh('CFG '+xbK,'error');
return;}
this.xVG=xVG;
var XmN=XmO||{};
var x7C;
if(typeof(XmN.XVW)=='string'){
var href=XmN.XVW;
var xHL=href.indexOf('?');
x7C=(xHL>=0?href.substr(0,xHL):href);}
else{
var x=self.location.search+self.location.hash;
var href=self.location.href;
x7C=href.substr(0,href.length-x.length);}
x7C=x7C.substr(0,x7C.lastIndexOf('/')+1);
this.XPz=x7C;
this.Xar=
typeof(XmN.Xa9)=='string'&&XmN.Xa9
?XmN.Xa9:x7C+'projects/global.js';
this.XmH=
typeof(XmN.XmG)=='string'&&XmN.XmG
?XmN.XmG:x7C+'projects/global_${mode}.js';
this.XXA=
typeof(XmN.XVq)=='boolean'
&&XmN.XVq?true:false;
this.x5r=
typeof(XmN.Xmn)=='boolean'&&
XmN.Xmn?true:false;
this.Xmm=
typeof(XmN.Xml)=='boolean'&&
XmN.Xml?true:false;
this.XmJ=XmJ;
this.XHh('CFG settings.base "'+x7C+'"','info');
this.XHh('CFG settings.global "'+this.Xar+'"','info');
this.XHh('CFG settings.mode-pat "'+this.XmH+'"','info');
this.XHh('CFG settings.flags'+
(this.XXA?' original':'')+
(this.x5r?' silent':'')+
(this.Xmm?' ignore-local-errs':''),
'info');
try{
this.dgoDOMAIN=parent.dgoDOMAIN;}
catch(xa8){
this.dgoDOMAIN=false;}
this.error='ok';
this.x6K=true;}
function XOh(){
var xd2='';
var name,XBK,value,xFJ;
var xAT=0;
for(name in this.XSI){
XBK=this.XSI[name];
value=this[XBK];
xFJ=name+':'+typeof(value)+' "'+value+'"';
if(xFJ.length+xAT>80){
if(xAT>0){
xd2+='\n\r';
xAT=0;}}
xd2+=xFJ+';';
xAT+=xFJ.length;}
return xd2;}
function XmX(){
var xbK='ctx';
for(var XCM in this){
XCM.substr(0,3)=='dgo'||(xbK+='\n\r'+
typeof(this[XCM])+' '+XCM+'="'+this[XCM]+'"');}
return xbK;}
function XPR(XGE,xGQ){
return true;};
xGB.prototype={
x6K:false
,error:'no-init'
,x1D:function(){
this.XmL(this.X7z);
this.X7z=null;
this.XmL(this.X53);
this.X53=null;
this.XmL(this.X8Y);
this.X8Y=null;
return true;}
,XnF:function(){
return this.XPz;}
,XRN:function(XGT,x8I){
var x1K=XGT||{};
this.XmD.XRK(x1K,this.XmJ,x8I);
x1K.toString=XOh;
return x1K;}
,X85:function(XGT){
var x1K={};
if(typeof(XGT)=='object'){
XA4(XGT,x1K,true);}
else{
x1K.udc={};}
this.X8w&&this.X8w.XZf(x1K);
this.XmE&&this.XmE.XZf(x1K);
this.XmD&&this.XmD.XZf(x1K);
return x1K;}
,X8v:function(X5Q,xfK){
var XGO;var i,xPL;
for(i=0;i<X5Q.length;++i){
xPL=X5Q[i];
if(xfK==xPL.n){
return this.XmD.X8v(xPL);}}
return XGO;}
,load:function(XQD,XCZ,XCY){
this.X7z||
(this.X7z=this.XVX());
this.X53||
(this.X53=this.XVX());
this.X8Y||
(this.X8Y=this.XVX());
if(this.dgoDOMAIN){if(XRl&&Xbp(this.X7z)||
XRl&&Xbp(this.X53)||
XRl&&Xbp(this.X8Y)||
XSS(this.X7z.contentWindow)||
XSS(this.X53.contentWindow)||
XSS(this.X8Y.contentWindow))
{var XwD=XQD;
var XwB=XCZ;
var XwA=XCY;
var Xjj=this;
var X1K=function(){
Xjj.load(XwD,XwB,XwA);}
this.XHh('CFG load->waiting for relaxation','info');
window.setTimeout(X1K,100);
return true;}}
this.XGh=new XAZ(XCZ,XCY);
this.XmD=new XJ2(XQD,this.XPz,this.XHh);
this.XHh('CFG load "'+XQD+'"','info');
if(!this.XmD.load(this.X7z,
this,this.XmB))
{
if(this.XmD.x6K||this.Xmm){
this.XHh('CFG Local config:'+
this.XmD.error,'warning');
this.XmD.x6K=true;
this.XmD.error='';
this.XmB(this.XmD);
return true;}
this.x6K=false;
this.error='Cannot load local config:'+this.XmD.error;
var xbK='Config::load:'+this.error;
this.XHh('CFG '+xbK,'error');
return false;}
return true;}
,xVG:null
,X7z:null
,X53:null
,X8Y:null
,XPz:null
,Xar:null
,XmH:null
,XmI:null
,Xmm:null
,XXA:null
,x5r:false
,XmF:'\$\{mode\}' 
,XmD:null
,X8w:null
,XmE:null
,XGh:null
,XHh:null
,XVX:function(){
var x4E=this.xVG.document;
var XDm=x4E.createElement('IFRAME');
if(!XDm){
return null;}
if(this.dgoDOMAIN){XDm.src=this.XPz+'relax_domain.html?dgoDOMAIN='+this.dgoDOMAIN;}
else{
XDm.src=this.XPz+'about_blank.html';}
XDm.style.display='none';
return x4E.body.appendChild(XDm);}
,XmB:function(XQE){
if(XQE.x6K){
this.XHh('CFG Config::loadLocalCb_:'+XQE.error);}
else{
this.error='Cannot read configfile "'+
XQE.Xu()+'":'+XQE.error;
var xbK='Config::loadLocalCb_:'+this.error;
if(!this.Xmm){
this.x6K=false;
this.XHh('CFG '+xbK,'error');
return this.XGh.exec('Config::loadLocalCb_():err1',this);}
this.XHh('CFG '+xbK,'warning');
XQE.x6K=true;
XQE.error='';}
this.XmD=XQE;
this.X8w=new XJ2(
'config='+this.Xar+'&ok=true','',this.XHh);
if(!this.X8w.load(this.X53,
this,this.XmA))
{
this.x6K=false;
this.error='Cannot load global configfile "'+
this.Xar+'":'+this.X8w.error;
xbK='Config::loadLocalCb_:'+this.error;
this.XHh('CFG '+xbK,'error');
return this.XGh.exec('Config::loadLocalCb_():err2',this);}
return true;}
,XmA:function(XQE){
if(!XQE.x6K){
this.x6K=false;
this.error='Cannot read global configfile "'+
XQE.Xu()+'":'+XQE.error;
var xbK='Config::loadGlobalCb_():'+this.error;
this.XHh('CFG '+xbK,'error');
return this.XGh.exec('Config::loadGlobalCb_():err1',this);}
var xKK=this.XmD.XEJ('mode');
if(!xKK){
var xAJ=this.XmD.XEJ('library');
if(xAJ&&xAJ!=''){
xKK='lib';}}
this.XHh('CFG Config::loadGlobalCb_:'+XQE.error+
',mode:"'+xKK+'"');
this.X8w=XQE;
if(!xKK){
return this.XIp('global');}
if(!this.X8Y){
this.XHh('CFG Config:cannot load mode:no IFRAME');
return this.XIp('global');}
this.XmI=this.XmH.replace(this.XmF,xKK);
this.XmE=new XJ2(
'config='+this.XmI+'&ok=true','',this.XHh);
if(!this.XmE.load(
this.X8Y,this,this.XmC))
{
this.x6K=false;
this.error='Cannot load mode configfile "'+
this.XmI+'":'+this.XmE.error;
xbK='Config::loadGlobalCb_:'+this.error;
this.XHh('CFG '+xbK,'error');
return this.XGh.exec('Config::loadGlobalCb_():err2',this);}
return true;}
,XmC:function(XQE){
if(!XQE.x6K){
this.x6K=false;
this.error='Cannot read mode configfile "'+
XQE.Xu()+'":'+XQE.error;
var xbK='Config::loadModeCb_():'+this.error;
this.XHh('CFG '+xbK,'error');
return this.XGh.exec('Config::loadModeCb_():err1',this);}
this.XmE=XQE;
this.XHh('CFG Config::loadModeCb_:'+XQE.error);
return this.XIp('mode');}
,XIp:function(XGE){
this.XHh('CFG Config::loaded_('+XGE+')');
this.XmD.XUI(this.XmJ,
this.X8w,this.XmE,this.XXA);
return this.XGh.exec('Config::loaded_():ok',this);}
,XmL:function(xsH){
var xpK=xsH&&xsH.parentNode.removeChild(xsH);
return xpK!=null;}}
//
function XJ2(xMj,XPz,XHh){
this.XPz=XPz||'';
this.XHh=XHh||XPR;
this.XT9={};
this.X2o={};
this.XQQ();
this.XS4(xMj);
try{
this.dgoDOMAIN=parent.dgoDOMAIN;}
catch(xa8){
this.dgoDOMAIN=false;}
this.error='ok';
this.x6K=true;}
function XJh(){
if(typeof(this.readyState)=='string'){
if(this.readyState!='complete'){
return true;}
this.onreadystatechange=null;}
else{
this.removeEventListener('load',XJh,true);}
if(!this.dgo32){
return false;}
var x=this.dgo32;
this.dgo32=null;
return x.XRo();}
XJ2.prototype={
x6K:false
,Xxb:false
,error:'no-init'
,XZf:function(XQF){
if(typeof(XQF.dgox)!='number'){
XQF.dgox=0;}
var XT6=this.XRT();
for(var XCM in XT6){
if(XCM.substr(0,4)=='udc.'){
if(typeof(XQF['udc'])=='undefined'){
XQF['udc']={};
++XQF.dgox;}
XQF.udc[XCM.substr(4)]=XT6[XCM];}
if(XCM.substr(0,12)=='control.udc.'){
if(typeof(XQF['udc'])=='undefined'){
XQF['udc']={};
++XQF.dgox;}
XQF.udc[XCM.substr(12)]=XT6[XCM];}
else if(XCM.substr(0,8)=='control.'){
XQF[XCM.substr(8)]=XT6[XCM];
++XQF.dgox;}}
if(this.xVG&&
this.xVG.cfg_control&&
typeof(this.xVG.cfg_control)=='object')
{
var xWE=this.xVG.cfg_control;
for(var XCM in xWE){
++XQF.dgox;
if(typeof(xWE[XCM])=='object'){
XA4(xWE[XCM],XQF[XCM],true);}
else{
XQF[XCM]=xWE[XCM];}}}}
,XUI:function(XQN,XUJ,XUK,X80){
var XGO;var xPL,name,value,X2q;
for(var i=0;i<XQN.length;++i){
xPL=XQN[i];
name=xPL.n;
if(xPL.xkI<=1){X2q=(XUK?XUK.XEJ(name):XGO);
if(typeof(X2q)=='undefined'){
value=(XUJ?XUJ.XEJ(name):XGO);
if(typeof(value)=='undefined'){
if(X80){
xPL.X55=xPL.xmE;
xPL.XPg=0;}}
else{
xPL.X55=value;
xPL.XPg=1;}}
else{
xPL.X55=X2q;
xPL.XPg=2;}}
else{
if(X80){
xPL.X55=xPL.xmE;
xPL.XPg=0;}}}}
,XEJ:function(xfK,XQP){
var xoQ=this.XRW(xfK);
if(typeof(xoQ)=='undefined'){
xoQ=this.XRO(xfK);}
if(typeof(xoQ)=='undefined'&&typeof(XQP)!='undefined'){
xoQ=XQP;}
return xoQ;}
,XRK:function(XGT,XQN,x8I){
var x7I=x8I||0;
var xYE=0;
var XSI={};
var i,xPL,name,value,X2q;
for(i=0;i<XQN.length;++i){
xPL=XQN[i];
XSI[xPL.n]=xPL.x;}
XGT.XSI=XSI;
for(i=0;i<XQN.length;++i){
xPL=XQN[i];
name=xPL.n;
if(xPL.xkI<=x7I){
value=this.XEJ(name,xPL.X55);
if(value===xPL.X55&&xPL.XPg==0&&
(xPL.xwK & 1))
{
X2q=this.X2U(name.toLowerCase());
if(typeof(X2q)!='undefined'){
value=X2q;}}
if(xPL.m){
if((xPL.XPg!=0)||(!this.X8v(xPL))){switch(name){
case 'keys_invertedkeys_PLAY':
if(!XGT.X6C){
XGT.X6C={};}
XGT.X6C['f8']=null;
value=value.split(',');
for(var n=0;n<value.length;n++){
XGT.X6C[value[n].XZA()]="_PLAY";}
break;
case 'keys_invertedkeys_STOP':
if(!XGT.X6C){
XGT.X6C={};}
XGT.X6C['f12']=null;
value=value.split(',');
for(var n=0;n<value.length;n++){
XGT.X6C[value[n].XZA()]="_STOP";}
break;
case 'keys_invertedkeys_PAUSE':
if(!XGT.X6C){
XGT.X6C={};}
XGT.X6C['pause']=null;
value=value.split(',');
for(var n=0;n<value.length;n++){
XGT.X6C[value[n].XZA()]="_PAUSE";}
break;
case 'keys_invertedkeys_PREV':
if(!XGT.X6C){
XGT.X6C={};}
XGT.X6C['shif_f8']=null;
value=value.split(',');
for(var n=0;n<value.length;n++){
XGT.X6C[value[n].XZA()]="_PREV";}
break;
case 'keys_invertedkeys_BACK':
if(!XGT.X6C){
XGT.X6C={};}
XGT.X6C['alt_up']=null;
value=value.split(',');
for(var n=0;n<value.length;n++){
XGT.X6C[value[n].XZA()]="_BACK";}
break;
case 'keys_invertedkeys_NEXT':
if(!XGT.X6C){
XGT.X6C={};}
XGT.X6C['alt_down']=null;
value=value.split(',');
for(var n=0;n<value.length;n++){
XGT.X6C[value[n].XZA()]="_NEXT";}
break;
case 'window_cfg_top':
case 'window_cfg_left':
case 'window_cfg_width':
case 'window_cfg_height':
case 'window_cfg_orientation':
case 'window_cfg_name':
if(!XGT.window){
XGT.window={};}
XGT.window[xPL.x.substr(7)]=this.XV5(value,xPL.js);
break;
case 'window_cfg_features_fullscreen':
case 'window_cfg_features_menubar':
case 'window_cfg_features_toolbar':
case 'window_cfg_features_location':
case 'window_cfg_features_resizable':
case 'window_cfg_features_scrollbars':
case 'window_cfg_features_status':
if(!XGT.window){
XGT.window={};}
if(value){
value='1';}
else{
value='0';}
if(!XGT.window.cfg_features){
XGT.window.cfg_features=name.substr(20)+'='+value;}
else{
XGT.window.cfg_features+=','+name.substr(20)+'='+value;}
break;
case 'topmost_style_cfg_base':
case 'topmost_style_cfg_scrollable':
case 'topmost_style_cfg_show_startpage':
case 'topmost_style_cfg_minigui':
case 'topmost_style_cfg_closeOnIdle':
case 'topmost_style_cfg_skin':
if(!XGT.Xok){
XGT.Xok={};}
XGT.Xok[xPL.x.substr(14)]=this.XV5(value,xPL.js);
break;
case 'lms_cfg_deactivate_lms':
case 'lms_cfg_ignore_errors':
case 'lms_cfg_use_original_max':
case 'lms_cfg_score_percentage_100':
case 'lms_cfg_score_precision':
case 'lms_cfg_only_one_commit':
case 'lms_cfg_score_precedence_lms':
case 'lms_cfg_decide_completeness':
if(!XGT.X27){
XGT.X27={};}
XGT.X27[xPL.x.substr(4)]=this.XV5(value,xPL.js);
break;
case 'librarydefaults_INP_Search':
case 'librarydefaults_INP_Filter':
case 'librarydefaults_INP_FlagInDescription':
case 'librarydefaults_INP_FlagInTitle':
case 'librarydefaults_INP_FlagKeepCourse':
case 'librarydefaults_INP_FlagNewWindow':
if(!XGT.XNl){
XGT.XNl={};}
XGT.XNl[xPL.x.substr(16)]=this.XV5(value,xPL.js);
break;}}}
else{
XGT[xPL.x]=this.XV5(value,xPL.js);}}}
XGT.xNE=(typeof(this.XQD)=='string'?this.XQD:'');
XGT.Xxb=this.Xxb;
for(i=0;i<XQN.length;++i){
xPL=XQN[i];
XGT[xPL.x]=this.XbW(XGT[xPL.x],XGT);}
return xYE;}
,x6U:function(){
return this.xVG;}
,Xu:function(){
return this.XQD;}
,XRT:function(){
return this.XT9;}
,X8v:function(XQN){
var name=XQN.n;
var xoQ;
if(XQN.xwK & 1){
if(this.X2U(name.toLowerCase())){
return false;}}
else{
xoQ=this.XRW(name)
if(typeof(xoQ)!='undefined'){
return false;}}
xoQ=this.XRO(name);
if(typeof(xoQ)!='undefined'){
return false;}
return(XQN.XPg==0);}
,load:function(XbL,XCZ,XCY){
this.XC0=new XAZ(XCZ,XCY);
if(this.XS3<=0){
this.error='Not loaded. No URL param.';
this.x6K=true;
return false;}
else if(!this.XQS()){
this.error='Not loaded. Neither tour nor config URL param.';
this.x6K=true;
return false;}
if(this.XQD===false){
this.error='Not loaded. program/library passed.';
this.x6K=true;
return false;}
this.XbL=XbL;
this.xVG=XbL.contentWindow;
this.error='Loading "'+this.XQD+'".';
if(!this.XRn()){
this.x6K=false;
return false;}
return true;}
,XPz:null
,XC0:null
,XbL:null
,xVG:null
,XT9:null,X2o:null,XT7:0
,XQD:null 
,XbV:/\$\{([a-zA-Z0-9_]+)\}/,XbX:/^\/[a-zA-Z]:$/
,XbW:function(XIH,XQE){
var xd2=XIH;
var match,name,value;
while(match=this.XbV.exec(xd2)){
name=match[1];
value=(XQE[XQE.XSI[name]]||'');
xd2=xd2.replace(new RegExp('\\$\\{'+name+'\\}','g'),value);}
return xd2;}
,XQQ:function(){
var XGO;
for(var XCM in this.xVG){
if(XCM.substr(0,4)=='cfg_'){
this.xVG[XCM]=XGO;}}
return true;}
,XQS:function(){
var Xav=this.XRW('tour');
if(Xav){
this.XQD='/tours/'+Xav;
return true;}
var xNE=this.XRW('config');
var mht=null;
var xKK=this.XRW('mode');
if(!xNE){
mht=this.XRW('mht');
xNE=mht;
if(!xKK){
xKK='demo';}}
if(xNE){
var xoL=xNE.indexOf('://');
if(xoL>=0){
xoL=(xNE.substr(xoL+3,3).search(this.XbX)==0
?xoL+6:xNE.indexOf('/',xoL+3));
this.XQD=xNE.substr(0,xoL)+
escape(xNE.substr(xoL));}
else if(xNE.substr(0,1)=='/'){
if((xoL=this.XPz.indexOf('://'))>=0){
xoL=this.XPz.indexOf('/',xoL+3);
this.XQD=(xoL>=0
?this.XPz.substr(0,xoL)+escape(xNE)
:this.XPz+'/'+escape(xNE));}
else{
this.XQD=escape(xNE);}}
else{
this.XQD=this.XPz+escape(xNE);}
if(mht){
this.XQD='mhtml:'+this.XQD+
'!http://dgo_mht_proxy/'+xKK+'.js';
this.Xxb=true;}
return true;}
var xBH=this.XRW('program')||this.XRW('library');
if(xBH){
this.XQD=false;
return true;}
return false;}
,XV5:function(XV7,Xlx){
if(Xlx==0){
return XV7;}
if(typeof(XV7)!='string'){
if(Xlx==1){return(typeof(XV7)=='object'&&XV7?XV7:null);}
return XV7;}
if(!XV7){
return null;}
try{
var XjL;
eval("XjL="+XV7);
return XjL;}
catch(xa8){}
return{
toString:function(){
return '{empty:eval("'+XV7+'")failed}';}};}
,XRW:function(xfK){
return this.XT9[xfK];}
,X2U:function(xfK){
return this.X2o[xfK];}
,XRO:function(xfK){
var XGO;
return(this.xVG?this.xVG['cfg_'+xfK]:XGO);}
,XRn:function(){
this.XbL.dgo32=this;
if(typeof(this.XbL.readyState)=='string'){
this.XbL.onreadystatechange=XJh;}
else{
this.XbL.addEventListener('load',XJh,true);}
var charset=this.XRW('charset')||'iso-8859-1';
var html=
'<html><head><meta http-equiv=Content-Type'+
' content="text/html;charset='+charset+'">\r\n';
if(this.dgoDOMAIN){
if(self.location.protocol=='http:'||
self.location.protocol=='https:')
{
html+=
'<script language=javascript>self.document.domain="'+
this.dgoDOMAIN+
'";</script>\r\n';}}
html+=
'<script language=javascript>\r\n'+
'var cfg_control={};\r\n'+
'cfg_control.udc={};\r\n'+'var udc=cfg_control.udc;\r\n'+
'</script>\r\n'+
'<script language=javascript id="config" src="'+this.XQD+
'"></'+'script>\r\n'+
'</head><body>datango Config</body></html>\r\n';
var x4E=this.xVG.document;
x4E.open('text/html');
try{
x4E.charset=charset;}
catch(xa8){
this.error+=' Exception setting charset to "'+charset+'";';}
x4E.write(html);
x4E.close();
return true;}
,XRo:function(){
if(this.XRW('ok')=='true'||this.xVG.cfg_ok){
this.error='Configfile "'+this.XQD+'" read.';
this.x6K=true;}
else{
this.error='Configfile "'+this.XQD+
'" not published or not found.';
this.x6K=false;}
this.XC0.exec('loaded',this);
return true;}
,XS4:function(xMj){
var xoL=xMj.indexOf('#');
var url=xoL>=0?xMj.substr(0,xoL):xMj;
var xPL=url.indexOf('?')>=0?url.split(/[?]/,2)[1]:url;
var XJj=xPL.split('&');
var xYE=0;
var name,value;
for(var i=0;i<XJj.length;++i){
xPL=XJj[i].split('=',2);
name=xPL[0];
if(name){
value=unescape(xPL[1]);
this.XT9[name]=value;
this.X2o[name.toLowerCase()]=value;
++this.XT7;}}
return this.XT7;}}
function TemplaterCloseWindow(){
if(navigator.appName=='Microsoft Internet Explorer'){
var X1K=function(){
self.top.opener=self.top;
self.top.open('','_parent');
self.top.close();}
window.setTimeout(X1K,2000);}
else{
self.setTimeout(xDK,2000);}}
function xDK(){
try{
self.top.close();}
catch(xaw){}
if(self.top&&!self.top.closed){
try{
netscape.security.PrivilegeManager.enablePrivilege(
'UniversalPreferencesRead UniversalPreferencesWrite');
navigator.preference('dom.allow_scripts_to_close_windows',true);
self.top.close();}
catch(xaw){alert('Cannot close browser window.\n\n'+
'To allow automatic window close,\n'+
'change the setting "dom.allow_scripts_to_close_windows"\n'+
'in "about:config" to true!');}}}
function cfg_trset(X6H,XIH){
return XX4(X6H,XIH);}
function cfg_tr(name,xvk,xwk,xaf,xae,xad,xac,xam,xan,xao){
return XQK(name,xvk,xwk,xaf,xae,xad,xac,xam,xan,xao);}
var Templater_OPTIONS_NONE=0;
function Templater(XKQ){
this.XKQ=XKQ||0;
var Xjj=this;
this.XHh=function(XGE,X7a){
Xjj.XGp(XGE,X7a);};
this.cfg_error='ok';
this.cfg_ok=true;}
var Templater_TYPE_STRING=1;
var Templater_TYPE_URL=2;
var Templater_TYPE_STYLEURL=3;
Templater.prototype={
cfg_ok:false
,cfg_error:'?'
,X78:{
'INPUT':[ Templater_TYPE_STRING,'value' ]
,'IMG':[ Templater_TYPE_URL,'src' ]
,'LINK':[ Templater_TYPE_URL,'href' ]
,'ALL_':[ Templater_TYPE_STRING,'title'
,Templater_TYPE_STRING,'alt'
,Templater_TYPE_STYLEURL,'style' ]}
,cfg_apply:function(xVG,XKQ){
this.XGp('TPLR apply('+xVG.name+'='+xVG.location+')start');
this.xVG=xVG;
this.XKQ |=(XKQ||0);
var x4E=xVG.document;
if(!x4E||!x4E.body){
this.cfg_ok=false;
this.cfg_error='No doc or doc.body';
this.XGp('TPLR apply():'+this.cfg_error);
return false;}
x4E.title=this.Xmd(x4E.title);
this.Xmh(x4E.documentElement);
this.XGp('TPLR apply():ok');
return(this.cfg_ok=true);}
,cfg_clearLog:function(){
this.XGE='';
return true;}
,cfg_getLog:function(){
return this.XGE;}
,cfg_getCtx:function(){
return this.XQF;}
,cfg_initConfig:function(XPz,XgP,XCZ,XCY){
this.XGp('TPLR initConfig('+XPz+')called');
this.XPz=XPz;
this.XgP=XgP;
this.XQE=null;
this.XQF=null;
this.Xh2=null;
this.xVG=null;
var Xjj=this;
var xNE=new xGB(this.XgP,{
Xml:true
,XVq:true
,Xmn:true
,XVW:this.XPz},XM4,this.XHh);
if(!xNE.x6K){
this.cfg_ok=false;
this.cfg_error='Config ctor:'+xNE.error;
this.XGp('TPLR '+this.cfg_error);
return false;}
this.Xh2=new XAZ(XCZ,XCY,this.XHh);
this.XGp('TPLR calling initConfig()');
if(!xNE.load(this.XPz,this,this.Xh5)){
this.cfg_ok=false;
this.cfg_error='Config::load():'+xNE.error;
this.XGp('TPLR '+this.cfg_error);
return false;}
this.XGp('TPLR initConfig()ok...waiting for cb.');
this.cfg_ok=true;
return true;}
,Xmj:function(XQE,XPz,XQF){
this.XPz=null;
this.XgP=null;
this.XPz=XPz;
this.XQE=XQE||{};
this.XQF=XQF||{};
this.Xh2=null;
this.xVG=null;
this.XGp('TPLR useConfig()done.');
this.cfg_ok=true;}
,xVG:null
,XgP:null
,XPz:null
,XQE:null,XQF:null
,Xh2:null
,XHh:null,XGE:'',XKQ:0
,Xh5:function(XQE){
this.XGp('TPLR initConfig():called...now loading dict.');
if(!XQE.x6K){
this.cfg_ok=false;
this.cfg_error='Config::load()cb:'+XQE.error;
this.XGp('TPLR '+this.cfg_error);
this.Xh2.exec('load failure',this);
this.Xh2=null;
return false;}
this.XQE=XQE.XRN(null,2);
this.XQF=XQE.X85();
XQE.x1D();
this.Xu5(this.XQE,'[object dgoConfig.sub]');
this.Xu5(this.XQF,'[object dgoControl.sub]');
var Xh6=','+this.XQE.Xf2+',';
this.XQE.XBe=
Xw5(this.XQE.XBe);
if(Xh6.indexOf(','+this.XQE.XBe+',')>=0){
this.XQE.XLf=this.XQE.XBe;}
else{
if(Xh6.indexOf(','+this.XQE.XLf+',')<0){
this.XQE.XLf=
XOk(this.XQE.Xf2);}}
this.XGp('TPLR Config:'+this.XQE);
var x7C=new Url(this.XPz);
xLJ('trainer',x7C);
var xAZ=new Url(this.XQE.xNE);
xAZ.xc3(x7C);
var XMH=new Url(this.XQE.XMG);
XMH.xc3(x7C);
var x=new Url(this.XQE.xGk||'data/');
x.xc3(x7C);
xLJ('data',x);
if(this.XQE.xAJ){
x=new Url(this.XQE.xAJ);
x.xc3(x7C);
xLJ('library',x);
xLJ('library-config',xAZ);
xLJ('library-project',XMH);}
else{
xLJ('trainer-config',xAZ);
xLJ('project',XMH);
x=new Url(this.XQE.xBH);
x.xc3(x7C);
xLJ('program',x);}
var Xmg=new Url('textatoms.'+this.XQE.XLf+'.txt');
Xmg.xc3(this.XPz);
this.XGp('TPLR Load Dict,lang='+
this.XQE.XLf+',url='+Xmg);
var xa7;
if(0<(xa7=XP0(Xmg.toString(),
this.XgP,this,this.Xm5,
this.XQE.xBb)))
{
return true;}
this.XGp('TPLR Dict_load()='+xa7);
return this.Xm5();}
,Xm5:function(X6k){
this.XGp('TPLR Dict loaded:'+(typeof(X6k)=='number'
?X6k+' entries read':X6k));
this.XGp('TPLR Add cfg_tr to Dict');
var xa7;
if(0<(xa7=XXt(this.XQE.xyP,
this.XQE.XBe,this.XPz,
this.XgP,this,this.Xm4)))
{
return true;}
this.XGp('TPLR Dict_setFromConfig()='+xa7);
return this.Xm4(0);}
,Xm4:function(X6k){
this.XGp('TPLR Dict(custom)loaded:'+
(typeof(X6k)=='number'
?X6k+' entries read':X6k));
this.XgP=null;
this.cfg_ok=true;
this.Xh2.exec('init ready',this);
this.Xh2=null;}
,XGp:function(XGE,X7a){
this.XGE+=XGE+(X7a?'':'\n\r');}
,Xu5:function(XQE,XGE){
var name,x;
var Xt3=XGE||'[dgo]';
var X1K=function(){return Xt3;}
for(name in XQE){
x=XQE[name];
if(x&&typeof(x)=='object'&&typeof(x.toString)=='undefined'){
x.toString=X1K;}}}
,Xmf:function(XGR){
var nodeType=XGR.nodeType;
if(nodeType==1){
this.Xm9(XGR);}
else if(nodeType==3){
XGR.nodeValue=this.Xmd(XGR.nodeValue);}}
,Xm9:function(XGR){
this.XGp('TPLR subst('+XGR.tagName+' '+XGR.id+')');
var XV3=this.X78['ALL_'].concat(
this.X78[XGR.tagName.toUpperCase()]||[]);
var i,xkI,type,a,xoQ;
for(i=0,xkI=XV3.length;i<xkI;++i){
type=XV3[i];
a=XV3[++i];
switch(type){
case Templater_TYPE_STRING:
if(typeof(xoQ=XGR[a])=='string'){
this.XGp('TPLR subst STRING '+a+'="'+xoQ+'"');
XGR[a]=this.Xmd(xoQ);}
else{
this.XGp('TPLR cannot subst '+a+
' ['+typeof(xoQ)+']:should be STRING');}
break;
case Templater_TYPE_URL:
xoQ=XOj(XGR,'dgo'+a)||
XOj(XGR,a);
XGR[a]=this.Xme(xoQ);
break;
case Templater_TYPE_STYLEURL:
this.Xmb(XGR);
break;
default:
this.XGp('TPLR cannot subst TYPE '+type+':not yet supported');
break;}}}
,Xma:/(url\()([^\)]*)(\))/i
,Xmb:function(XGR){
var src,X79;
if(XGR.style&&typeof(XGR.style.cssText)=='string'){
src=XGR.style.cssText;
X79=true;}
else if(XGR.attributes&&XGR.attributes['style']&&
XGR.attributes['style'].nodeValue)
{
src=XGR.attributes['style'].nodeValue;
X79=false;}
else{
return false;}
var XLw=src;
var xAc='';
var match=this.Xma.exec(src);
var url;
while(match){
xAc+=src.substr(0,match.index);
if(match[2]&&match[2]=='none'){
xAc+=match[0];}
else{
url=new Url(match[2]||'');
url.xc3(this.XPz);
xAc+=(match[1]||'')+url+(match[3]||'');}
src=src.substr(match.index+match[0].length);
match=this.Xma.exec(src);}
this.XGp('TPLR StyleURL:"'+XLw+'"==>"'+xAc+'"');
if(X79){
XGR.style.cssText=xAc+src;}
else{
XGR.attributes['style'].nodeValue=xAc+src;}
return true;}
,Xmc:/\$\{[A-Za-z_][A-Za-z0-9_.]+\}/
,Xmd:function(xyO){
var src=xyO;
var xAc='';
var xoL=src.search(this.Xmc);
var XYt,xkP;
while(xoL>=0){
xAc+=src.substr(0,xoL);
src=src.substr(xoL+2);
XYt=src.indexOf('}');
if(XYt>=0){
xkP=src.substr(0,XYt);
xAc+=XQK(xkP);
src=src.substr(XYt+1);
xoL=src.search(this.Xmc);}
else{
xoL=-1;}}
xAc+=src;
this.XGp('TPLR subst "'+xyO+'"=>"'+xAc+'"');
return xAc;}
,Xme:function(Xmi){
var url=new Url(Xmi);
this.XGp('TPLR URL:"'+Xmi+'"==>"'+url+'"');
return url.toString();}
,Xmh:function(XGR){
var children=XGR.childNodes;
var xkI=children.length;
var i,child;
this.Xmf(XGR);
for(i=0;i<xkI;++i){
child=children[i];
this.Xmh(child);}
return true;}}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
