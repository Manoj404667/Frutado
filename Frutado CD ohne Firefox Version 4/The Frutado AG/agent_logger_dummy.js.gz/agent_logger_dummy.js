//
var Xkf=/;[ ]*/;
function XAW(XCI){
if(!XCI)return;
this.error='@L no logging due to config';
this.x6K=true;
return;}
XAW.prototype={
x6K:false
,error:''
,load:function(){
return true;}
,XEu:function(){
return true;}
,send:function(){
return true;}}
if(self.XI7){XI7.XJB(new XIX('../agent_logger_dummy.js'));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
