//
function xxR(x8Q){
if(!x8Q.document.body){
dgoAgent.Xpr('XS ERROR xb_page_x:no doc.body');
return 0;}
return x8Q.document.body.scrollWidth;}
function xyR(x8Q){
if(!x8Q.document.body){
dgoAgent.Xpr('XS ERROR xb_page_y:no doc.body');}
return x8Q.document.body.scrollHeight;}
var x6q=null;
var X7O=1500;
function xOI(xMj){
x6q==null&&
(x6q=xNE.XRX>0?xNE.XRX:24);
if(x6q>=5&&dgoAgent.XFI_('moz','1.4')){
x6q-=3;
dgoAgent.XF3().parent.document.body.rows=
'*,'+x6q;
setTimeout("xOI("+xMj.XPC()+")",13);
X7O=1;}else{
setTimeout("xcI("+
xMj.XPC()+")",X7O);}}
if(self.XI7){XI7.XJB(new XIX(
'../standard.js',['dhtml_standard.js','../xbrowser.js']));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
