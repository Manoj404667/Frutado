
function logphp_do_onload_(){
if(parent&&
parent.frames&&
typeof(parent.frames.trainer_program_frame)=='object'&&
typeof(parent.frames.trainer_program_frame.dgo7)=='object'&&
typeof(parent.frames.trainer_program_frame.dgo7.XK0)=='object'&&
parent.frames.trainer_program_frame.dgo7.XK0)
{
return parent.frames.trainer_program_frame.dgo7.XK0.XGj();}}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
