//
function xxR(x8Q){
return(typeof(x8Q.document)=='unknown'?0:x8Q.document.body.scrollWidth);}
function xyR(x8Q){
return(typeof(x8Q.document)=='unknown'?0:x8Q.document.body.scrollHeight);}
var x6q=null;
function xOI(xMj){
x6q==null&&
(x6q=xNE.XRX>0?xNE.XRX:24);
if(x6q>=5){
x6q-=3;
dgoAgent.XF3().parent.document.body.rows=
'*,'+x6q;
self.setTimeout("xOI("+xMj.XPC()+")",20);}else{
xcI(xMj);}
return true;}
if(self.XI7){XI7.XJB(new XIX(
'../explorer.js',['dhtml_explorer.js','../xbrowser.js']));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
