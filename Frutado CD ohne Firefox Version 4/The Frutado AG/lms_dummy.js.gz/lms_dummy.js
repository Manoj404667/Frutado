//
function X0h(xVG,XQE,XKF){
if(!XQE)return;
this.XQE=XQE;
this.x6K=true;}
X0h.prototype={
x6K:false
,error:'ok'
,X1r:function(XFj,X1w){
return true;}
,x3H:function(){
return true;}
,x8F:function(X0D,X1w,XCZ,XCY){
return false;}
,X2i:function(X28,X2a,XZg){
if(typeof(X28)=='number'){
this.X2d=X28;}
if(typeof(X2a)=='number'){
this.X2e=X2a;}
if(typeof(XZg)=='number'){
this.X2h=XZg;}}
,X5G:function(){
return{
max:this.X2d||0
,pass:this.X2e||0
,current:this.X2h||0
,scaled:((this.X2d||0)>0
?(this.X2h||0)/this.X2d:null)}}
,X2P:function(){
return '';}
,X2Q:function(){
return '';}
,X2R:function(){
return '';}
,XOz:function(){
return '';}
,X2S:function(){
return '';}
,X2T:function(){
return '0';}
,toString:function(){
return 'LMSdummy={'+this.X2h
';max:'+this.X2d+
';pass:'+this.X2e+
'}';}
,XQE:null 
,X2e:null,X2d:null,X2h:null}
if(self.XI7){XI7.XJB(new XIX('../lms_dummy.js'));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
