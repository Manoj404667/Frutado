//
//
Function.prototype.xkF=function(Xaa,xvk,xwk,xaf,xae,xad,xac,xam,xan,xao){
var xaw=new Object;
try{
xaw.xd2=this(Xaa,xvk,xwk,xaf,xae,xad,xac,xam,xan,xao);
xaw.type=null;}
catch(xa8){
xaw=new x6C(xa8);
xaw.xd2=null;}
return xaw;}
if(self.XI7){
XI7.XJB(
new XIX('js_extensions_standard.js',['js_extensions.js']));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
