//
//
//
function evt_simple(xCi,id){
var e=new xNh(id,xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_cancelWait(xCi,XKQ){
var e=new XLF(xCi,XKQ);
dgo7.XXe().xbz(e);
return e;}
function evt_clearTransition(xCi,XKQ){
var e=new XLG(xCi,XKQ);
dgo7.XXe().xbz(e);
return e;}
function evt_clearTrigger(xCi,XKQ){
var e=new XL4(xCi,XKQ);
dgo7.XXe().xbz(e);
return e;}
function evt_clearValue(xCi,XKQ){
var e=new XMa(xCi,XKQ);
dgo7.XXe().xbz(e);
return e;}
function evt_cursor(xCi,shape,orientation,rgbcolor){
var e=new xJj(xCi,shape,orientation,rgbcolor);
dgo7.XXe().xbz(e);
return e;}
function evt_defineTransition(xCi,
X4E,xGQ,X7G,X4W)
{
var e=new XP5(xCi,
X4E,xGQ,X7G,X4W);
dgo7.XXe().xbz(e);
return e;}
function evt_formtext(xCi,xUG,xbF,xxj,start,end,text){
var e=new xwj(xCi,xUG,xbF,xxj,start,end,text);
dgo7.XXe().xbz(e);
return e;}
function evt_formcheck(xCi,xUG,xbF,xxj,value){
var e=new xuh(xCi,xUG,xbF,xxj,value);
dgo7.XXe().xbz(e);
return e;}
function evt_formselect1(xCi,xUG,xbF,xxj,xDN,duration){
var e=new xTj(xCi,xUG,xbF,xxj,xDN,duration);
dgo7.XXe().xbz(e);
return e;}
function evt_formselect(xCi,xUG,xbF,xxj,xDN,xSj){
var e=new xgj(xCi,xUG,xbF,xxj,xDN,xSj);
dgo7.XXe().xbz(e);
return e;}
function evt_highlight(xCi,xUG,xbF,effect,width,color,x3k,xRM,x2k,xAl){
return evt_highlight2(xCi,xUG,xbF,effect,
width,color,null,x3k,xRM,x2k,xAl);}
function evt_highlight2(xCi,xUG,xbF,effect,
width,color,x5f,x3k,xRM,x2k,xAl,off,xfk)
{
var e=new Xkx(xCi,xUG,xbF,effect,
width,color,x5f,x3k,xRM,x2k,xAl,off,xfk);
dgo7.XXe().xbz(e);
return e;}
function evt_installTrigger(xCi,xUG,element,
xGQ,X7G,X6u,XKQ,X4E)
{
var e=new X2y(xCi,xUG,element,
xGQ,X7G,X6u,XKQ,X4E);
dgo7.XXe().xbz(e);
return e;}
function evt_javascript(xCi,xUG,xbF,text){
var e=new x1h(xCi,xUG,xbF,text);
dgo7.XXe().xbz(e);
return e;}
function evt_loaded(xCi){
var e=new xyj(xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_macrocall(xCi,xUG,xbF,Xzn,Xzr){
var e=new Xzk(xCi,xUG,xbF,Xzn,Xzr);
dgo7.XXe().xbz(e);
return e;}
function evt_mouse(xCi,xUG,xbF,x3k,x2k,off,type,duration){
if(type=='hide')
return evt_mousehide(xCi);
var e=new xxh(xCi,xUG,xbF,x3k,x2k,off,type,duration);
dgo7.XXe().xbz(e);
return e;}
function evt_mousehide(xCi){
var e=new xbj(xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_off(xCi){
var e=new xvF(xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_pause(xCi,type,timeout){
if(type=='timeout')
return evt_timeout(xCi,timeout);
var e=new xei(xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_scroll(xCi,xUG,xbF,x3k,x2k,xYk,duration,XFs){
var e=new xBl(xCi,xUG,xbF,x3k,x2k,xYk,duration,XFs);
dgo7.XXe().xbz(e);
return e;}
function evt_storeValue(xCi,XIH,XKQ){
var e=new X3E(xCi,XIH,XKQ);
dgo7.XXe().xbz(e);
return e;}
function evt_textbubble(xCi,xUG,xbF,x3k,x2k,off,xAh,xYk,
text,replace,w,h,type,spike)
{
if(type&&type=='close'){
return evt_textbubbleclose(xCi);}
dgo7.XlH&&(xAh.cfg_xframe=false);
dgo7.XlH&&(xAh.cfg_onTop=false);
var e=new xLh(xCi,xUG,xbF,x3k,x2k,off,xAh,xYk,
text,replace,w,h,spike);
dgo7.XXe().xbz(e);
return e;}
function evt_textbubbleclose(xCi){
var e=new xIi(xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_textwindow(xCi){
var e=new xNh(XAw,xCi);
dgo7.XXe().xbz(e);
return e;}
function evt_timeout(xCi,timeout){
var e=new xFh(xCi,timeout);
dgo7.XXe().xbz(e);
return e;}
function evt_trackValue(
xCi,xUG,element,XKQ,X4E,X4s,X91)
{
var e=new X3K(xCi,
xUG,element,XKQ,X4E,X4s,X91);
dgo7.XXe().xbz(e);
return e;}
function evt_url(xCi,xUG,url,Xss,x0g,method,encoding,xGk){
var e=new xwi(xCi,xUG,url,Xss,x0g,method,encoding,xGk);
dgo7.XXe().xbz(e);
return e;}
function evt_wait(xCi,XKQ){
var e=new X3h(xCi,XKQ);
dgo7.XXe().xbz(e);
return e;}
function evt_watch(xCi,XKQ,X4U,X6U,X4W){
var e=new X8j(xCi,XKQ,X4U,X6U,X4W);
dgo7.XXe().xbz(e);
return e;}
function evt_window(xCi,xUG,url,name,XfO,xXM,
XGl,XHd,XG5,status,xc4_,xc2,type)
{
if(type&&type=='close')
return evt_windowclose(xCi,xUG);
var xxk='';
var x7Q,xdH,XfV,xeS,xsF;
if(typeof(XfO)=='object'&&XfO){
XfV=XfO.x;
xeS=XfO.y;}
else if(typeof(XfO)=='number'){
x7Q=XfO;
XfV=null;
xeS=null;}
else if(typeof(XfO)=='string'){
XfV=XfO;
xeS=null;}
if(typeof(xXM)=='object'&&xXM){
x7Q=xXM.w;
xdH=xXM.h;}
else if(typeof(xXM)=='number'){
xdH=xXM;}
xxk=
'location='+(XGl?'1':'0')+
',toolbar='+(XHd?'1':'0')+
',menubar='+(XG5?'1':'0')+
',status='+(status?'1':'0')+
',scrollbars='+(xc4_?'1':'0')+
',resizable='+(xc2?'1':'0');
var e=new xlj(xCi,xUG,url,name,xxk,
XfV,xeS,x7Q,xdH);
dgo7.XXe().xbz(e);
return e;}
function evt_windowclose(xCi,xUG){
var e=new xMi(xCi,xUG);
dgo7.XXe().xbz(e);
return e;}
if(self.XI7){XI7.XJB(new XIX('../eventfactory.js',['../events.js']));}

/*
  Copyright Notice:

  Copyright 2000-2005 datango AG
  ALL RIGHTS RESERVED

  UNPUBLISHED -- Use of a copyright notice is precautionary only and
  does not imply publication or disclosure.

  THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
  INFORMATION OF DATANGO AG. ANY DUPLICATION, MODIFICATION,
  DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS
  STRICTLY PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF
  DATANGO AG.

*/
